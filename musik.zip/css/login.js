function myfade(){
    var my = document.getElementById("div-alert");
    my.style.display='none';
    var kamu = inp.value;
    var mine = "</br><a href='musik/index.html'> Lanjutkan</a>";
    paste.innerHTML = `<i class="fas fa-heart"></i></br>` + "Hallo" + "Nikmati musik secara gratis" + "</br>Terima kasih!";
    if(inp.value =="AraYad"){
         paste.innerHTML =  `<i class="fas fa-heart"></i></br>` + "Selamat datang<br>" + "Nikmati musik secara gratis<br>"+ "<a href='musik/index.html'>Lanjutkan</a>";
         alert('Hallo ' + inp.value);
         foot.style.display='block';
    } else{
        var myip = "Password salah gan" + "<br>" + "Balekk" + "<br>" + "<a href='awasheker.html'> sini balik!</a>"
        paste.innerHTML =  `<i class="fas fa-user-circle"></i></br>` + myip ;
        foot.style.display='none';
    }
}
function load(){
    document.getElementsByClassName("loader")[0].style.display='none';
}
setInterval(load,2000);